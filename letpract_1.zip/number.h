#ifndef NUMBER_H
#define NUMBER_H
#include <QTextStream>
class Number {
private:
    int num;

public:
    Number();
    Number(int val);
    ~Number();
    bool prostoe(int n) {
        if (n <= 1) return false;
        for (int i = 2; i * i <= n; ++i) {
            if (n % i == 0) return false;
        }
        return true;
    }
    void MaxCh();
    int gcd(const Number& other);
    void step();
    void poiskch(int X, int Y);
    friend QTextStream& operator>>(QTextStream& in, Number& number) {
        in >> number.num;
        return in;
    }
    friend QTextStream& operator<<(QTextStream& out, const Number& number) {
        out << number.num;
        return out;
    }
};

#endif // NUMBER_H
