#include "mainwindow.h"
#include "number.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->stackedWidget->hide();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    int T = ui->task->text().toInt();
    switch(T){
    case 1:
         ui->stackedWidget->setCurrentIndex(0);
         ui->stackedWidget->show();
         break;
    case 2:
        ui->stackedWidget->setCurrentIndex(1);
        ui->stackedWidget->show();
        break;
    case 3:
        ui->stackedWidget->setCurrentIndex(2);
        ui->stackedWidget->show();
        break;
    case 4:
        ui->stackedWidget->setCurrentIndex(3);
        ui->stackedWidget->show();
        break;
    default:
        QMessageBox::critical(this, "Ошибка", "Такого номера не существует");
        ui->task->clear();
    }
}


void MainWindow::on_pushButton_5_clicked()
{
    Number S1 = ui->step->text().toInt();
    S1.step();

}


void MainWindow::on_pushButton_4_clicked()
{
    int X = ui->p1->text().toInt();
    int Y = ui->p2->text().toInt();
    Number an;
    an.poiskch(X,Y);
}


void MainWindow::on_pushButton_3_clicked()
{
    Number N1 = ui->nod1->text().toInt();
    Number N2 = ui->nod2->text().toInt();
    N1.gcd(N2);
}


void MainWindow::on_pushButton_2_clicked()
{
    Number M1 = ui->dub->text().toInt();
    M1.MaxCh();
}

