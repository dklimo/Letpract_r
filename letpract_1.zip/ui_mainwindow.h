/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QStackedWidget *stackedWidget;
    QWidget *page_3;
    QGridLayout *gridLayout;
    QGroupBox *groupBox;
    QLineEdit *step;
    QLabel *label_6;
    QPushButton *pushButton_5;
    QWidget *page_4;
    QGridLayout *gridLayout_2;
    QGroupBox *groupBox_2;
    QLabel *label_7;
    QLineEdit *p1;
    QLineEdit *p2;
    QPushButton *pushButton_4;
    QWidget *page_5;
    QGridLayout *gridLayout_3;
    QGroupBox *groupBox_3;
    QLabel *label_8;
    QLineEdit *nod1;
    QLineEdit *nod2;
    QPushButton *pushButton_3;
    QWidget *page_6;
    QGridLayout *gridLayout_4;
    QGroupBox *groupBox_4;
    QLabel *label_9;
    QLineEdit *dub;
    QPushButton *pushButton_2;
    QLabel *label_10;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QWidget *widget1;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_5;
    QHBoxLayout *horizontalLayout;
    QLineEdit *task;
    QPushButton *pushButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(800, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        stackedWidget = new QStackedWidget(centralwidget);
        stackedWidget->setObjectName("stackedWidget");
        stackedWidget->setGeometry(QRect(30, 250, 261, 221));
        page_3 = new QWidget();
        page_3->setObjectName("page_3");
        gridLayout = new QGridLayout(page_3);
        gridLayout->setObjectName("gridLayout");
        groupBox = new QGroupBox(page_3);
        groupBox->setObjectName("groupBox");
        step = new QLineEdit(groupBox);
        step->setObjectName("step");
        step->setGeometry(QRect(60, 100, 113, 28));
        label_6 = new QLabel(groupBox);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(60, 70, 111, 20));
        pushButton_5 = new QPushButton(groupBox);
        pushButton_5->setObjectName("pushButton_5");
        pushButton_5->setGeometry(QRect(70, 150, 83, 29));

        gridLayout->addWidget(groupBox, 0, 0, 1, 1);

        stackedWidget->addWidget(page_3);
        page_4 = new QWidget();
        page_4->setObjectName("page_4");
        gridLayout_2 = new QGridLayout(page_4);
        gridLayout_2->setObjectName("gridLayout_2");
        groupBox_2 = new QGroupBox(page_4);
        groupBox_2->setObjectName("groupBox_2");
        label_7 = new QLabel(groupBox_2);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(60, 50, 111, 20));
        p1 = new QLineEdit(groupBox_2);
        p1->setObjectName("p1");
        p1->setGeometry(QRect(60, 80, 113, 28));
        p2 = new QLineEdit(groupBox_2);
        p2->setObjectName("p2");
        p2->setGeometry(QRect(60, 120, 113, 28));
        pushButton_4 = new QPushButton(groupBox_2);
        pushButton_4->setObjectName("pushButton_4");
        pushButton_4->setGeometry(QRect(70, 160, 83, 29));

        gridLayout_2->addWidget(groupBox_2, 0, 0, 1, 1);

        stackedWidget->addWidget(page_4);
        page_5 = new QWidget();
        page_5->setObjectName("page_5");
        gridLayout_3 = new QGridLayout(page_5);
        gridLayout_3->setObjectName("gridLayout_3");
        groupBox_3 = new QGroupBox(page_5);
        groupBox_3->setObjectName("groupBox_3");
        label_8 = new QLabel(groupBox_3);
        label_8->setObjectName("label_8");
        label_8->setGeometry(QRect(60, 50, 111, 20));
        nod1 = new QLineEdit(groupBox_3);
        nod1->setObjectName("nod1");
        nod1->setGeometry(QRect(60, 80, 113, 28));
        nod2 = new QLineEdit(groupBox_3);
        nod2->setObjectName("nod2");
        nod2->setGeometry(QRect(60, 120, 113, 28));
        pushButton_3 = new QPushButton(groupBox_3);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setGeometry(QRect(80, 160, 83, 29));

        gridLayout_3->addWidget(groupBox_3, 0, 0, 1, 1);

        stackedWidget->addWidget(page_5);
        page_6 = new QWidget();
        page_6->setObjectName("page_6");
        gridLayout_4 = new QGridLayout(page_6);
        gridLayout_4->setObjectName("gridLayout_4");
        groupBox_4 = new QGroupBox(page_6);
        groupBox_4->setObjectName("groupBox_4");
        label_9 = new QLabel(groupBox_4);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(60, 70, 111, 20));
        dub = new QLineEdit(groupBox_4);
        dub->setObjectName("dub");
        dub->setGeometry(QRect(60, 100, 113, 28));
        pushButton_2 = new QPushButton(groupBox_4);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(70, 140, 83, 29));

        gridLayout_4->addWidget(groupBox_4, 0, 0, 1, 1);

        stackedWidget->addWidget(page_6);
        label_10 = new QLabel(centralwidget);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(570, 520, 221, 21));
        widget = new QWidget(centralwidget);
        widget->setObjectName("widget");
        widget->setGeometry(QRect(30, 30, 654, 103));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setObjectName("verticalLayout_2");
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget);
        label->setObjectName("label");

        verticalLayout_2->addWidget(label);

        label_2 = new QLabel(widget);
        label_2->setObjectName("label_2");

        verticalLayout_2->addWidget(label_2);

        label_3 = new QLabel(widget);
        label_3->setObjectName("label_3");

        verticalLayout_2->addWidget(label_3);

        label_4 = new QLabel(widget);
        label_4->setObjectName("label_4");

        verticalLayout_2->addWidget(label_4);

        widget1 = new QWidget(centralwidget);
        widget1->setObjectName("widget1");
        widget1->setGeometry(QRect(40, 170, 292, 60));
        verticalLayout_3 = new QVBoxLayout(widget1);
        verticalLayout_3->setObjectName("verticalLayout_3");
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(widget1);
        label_5->setObjectName("label_5");

        verticalLayout_3->addWidget(label_5);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        task = new QLineEdit(widget1);
        task->setObjectName("task");

        horizontalLayout->addWidget(task);

        pushButton = new QPushButton(widget1);
        pushButton->setObjectName("pushButton");

        horizontalLayout->addWidget(pushButton);


        verticalLayout_3->addLayout(horizontalLayout);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 800, 25));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(3);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        groupBox->setTitle(QCoreApplication::translate("MainWindow", "\320\227\320\260\320\264\320\260\320\275\320\270\320\265 1. \320\241\321\202\320\265\320\277\320\265\320\275\321\214", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "\320\222\320\262\320\265\320\264\320\270\321\202\320\265 \321\207\320\270\321\201\320\273\320\276", nullptr));
        pushButton_5->setText(QCoreApplication::translate("MainWindow", "OK", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("MainWindow", "\320\227\320\260\320\264\320\260\320\275\320\270\320\265 2. \320\237\321\200\320\276\321\201\321\202\321\213\320\265 \321\207\320\270\321\201\320\273\320\260", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "\320\222\320\262\320\265\320\264\320\270\321\202\320\265 \321\207\320\270\321\201\320\273\320\260", nullptr));
        pushButton_4->setText(QCoreApplication::translate("MainWindow", "OK", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("MainWindow", "\320\227\320\260\320\264\320\260\320\275\320\270\320\265 3. \320\235\320\236\320\224", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "\320\222\320\262\320\265\320\264\320\270\321\202\320\265 \321\207\320\270\321\201\320\273\320\260", nullptr));
        pushButton_3->setText(QCoreApplication::translate("MainWindow", "OK", nullptr));
        groupBox_4->setTitle(QCoreApplication::translate("MainWindow", "\320\227\320\260\320\264\320\260\320\275\320\270\320\265 4. \320\224\321\203\320\261\320\273\320\270\321\200\320\276\320\262\320\260\320\275\320\270\320\265", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "\320\222\320\262\320\265\320\264\320\270\321\202\320\265 \321\207\320\270\321\201\320\273\320\276", nullptr));
        pushButton_2->setText(QCoreApplication::translate("MainWindow", "OK", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "\320\232\320\273\320\270\320\274\320\276\320\262\321\207\320\270 \320\224\320\260\321\200\321\214\321\217, 5 \320\263\321\200\321\203\320\277\320\277\320\260", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "1. \320\236\320\277\321\200\320\265\320\264\320\265\320\273\320\270\321\202\321\214, \320\274\320\265\320\266\320\264\321\203 \320\272\320\260\320\272\320\270\320\274\320\270 \321\201\321\202\320\265\320\277\320\265\320\275\321\217\320\274\320\270 \320\264\320\262\320\276\320\271\320\272\320\270 \320\275\320\260\321\205\320\276\320\264\320\270\321\202\321\201\321\217 \321\207\320\270\321\201\320\273\320\276.", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "2. \320\235\320\260\320\271\321\202\320\270 \321\202\320\260\320\272\320\270\320\265 \320\277\321\200\320\276\321\201\321\202\321\213\320\265 \321\207\320\270\321\201\320\273\320\260 P1 \320\270 P2, \321\207\321\202\320\276 X * X - Y * Y = P1 * P2.", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "3.  \320\235\320\260\320\271\321\202\320\270 \320\275\320\276\320\264 \321\207\320\270\321\201\320\265\320\273.", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "4. \320\237\321\200\320\276\320\264\321\203\320\261\320\273\320\270\321\200\320\276\320\262\320\260\321\202\321\214 \320\272\320\260\320\266\320\264\320\276\320\265 \320\262\321\205\320\276\320\266\320\264\320\265\320\275\320\270\320\265 \320\275\320\260\320\270\320\261\320\276\320\273\321\214\321\210\320\265\320\271 \321\206\320\270\321\204\321\200\321\213, \320\270\321\201\320\277\320\276\320\273\321\214\320\267\321\203\320\265\320\274\320\276\320\271 \320\262 \320\267\320\260\320\277\320\270\321\201\320\270 \321\207\320\270\321\201\320\273\320\260 A. ", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "\320\222\320\262\320\265\320\264\320\270\321\202\320\265 \320\275\320\276\320\274\320\265\321\200 \320\267\320\260\320\264\320\260\321\207\320\270", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "\320\236\320\232", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
