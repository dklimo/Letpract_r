#include "number.h"
#include <QString>
#include <QMessageBox>
Number:: Number() : num(0) {}
Number:: Number(int val) : num(val) {}
Number:: ~Number() {
    QTextStream out(stdout);
    out << "\nDestructor called.\n";
}
void Number:: MaxCh(){
    int A = num, max = 0, Aa = 0, m = 1;
    while (A) {
        int x = A % 10;
        if (x > max) max = x;
        A /= 10;
    }

    A = num;
    while (A > 0) {
        int z = A % 10;
        if (z == max) {
            Aa += z * m;
            m *= 10;
            Aa += z * m;
        } else {
            Aa += z * m;
        }
        A /= 10;
        m *= 10;
    }
    QString message = QString("Исходное число: %1\nМаксимальная цифра: %2\nРезультат обработки: %3")
                          .arg(num)
                          .arg(max)
                          .arg(Aa);

    QMessageBox::information(nullptr, "Обработка числа", message);
}
int Number:: gcd(const Number& other){
    int a = num, b = other.num;
    if (a == 0 && b == 0) return -1;
    if (a == 0) return b;
    if (b == 0) return a;

    int count = 0;
    while ((a & 1) == 0 && (b & 1) == 0) {
        a >>= 1;
        b >>= 1;
        count++;
    }
    while ((a & 1) == 0) {
        a >>= 1;
    }
    while (b != 0) {
        while ((b & 1) == 0) {
            b >>= 1;
        }
        if (a > b) {
            a = (a - b) >> 1;
        } else {
            b = (b - a) >> 1;
        }
    }
    int result = a << count;
    QString message;
    if (result == -1) {
        message = "НОД не существует (оба числа равны 0)";
    } else {
        message = QString("НОД чисел %1 и %2 равен: %3")
                      .arg(num)
                      .arg(other.num)
                      .arg(result);
    }

    QMessageBox::information(nullptr, "Результат НОД", message);

    return result;
}

void Number::poiskch(int X, int Y){
    int P = X * X - Y * Y;
    int P1 = -1, P2 = -1;

    for (int i = 2; i < P; ++i) {
        if (prostoe(i)) {
            for (int d = i; d < P; ++d) {
                if (prostoe(d) && i * d == P) {
                    P1 = i;
                    P2 = d;
                    break;
                }
            }
        }
        if (P1 != -1) break;
    }
    QString message;
    if (P1 != -1 && P2 != -1) {
        message = QString("Найдены простые числа P1 = %1 и P2 = %2").arg(P1).arg(P2);
    } else {
        message = "Не удалось найти подходящие простые числа P1 и P2.";
    }

    QMessageBox::information(nullptr, "Результат поиска", message);
}
void Number::step(){
    int x = num;
    int b = 0, c = 1;
    while (c < x) {
        b++;
        c = 1 << b;
    }
    QString message = QString("Число %1 между %2 (2^%3) и %4 (2^%5).")
                          .arg(x)
                          .arg(c >> 1)
                          .arg(b - 1)
                          .arg(c)
                          .arg(b);

    QMessageBox::information(nullptr, "Ответ", message);
}
