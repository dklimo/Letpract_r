/* Климович Дарья, 5 группа, 1 курс.
3.	Строка состоит из слов. За один просмотр символов строки найти все слова, начинающиеся с гласных букв,
и занести их в новую строку, заменяя первую букву каждого слова на прописную.
Слова в исходной строке разделяются некоторым множеством разделителей.
Слова в новой строке должны разделяться ровно одним пробелом.
*/
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QRegularExpression>
#include <QString>
#include <QMessageBox>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    ui->stackedWidget->hide();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{

    static QRegularExpression splregex(R"([^\w]+)");
    static QRegularExpression vregex(R"(^[aeiouAEIOU])");
    static QRegularExpression rusregex(R"([а-яА-ЯёЁ])");

    QString str = ui->stroka->text().trimmed();

    if (str.isEmpty()) {
        QMessageBox::information(this, "Ошибка", "Введена пустая строка");
        return;
    }
    if (rusregex.match(str).hasMatch()) {
        QMessageBox::warning(this, "Ошибка", "Введены русские буквы! Допустимы только английские.");
        return;
    }

    QStringList words = str.split(splregex, Qt::SkipEmptyParts);
    QStringList Wlist;
    for (QString &word : words) {
        if (vregex.match(word).hasMatch()) {
            word = word[0].toUpper() + word.mid(1).toLower();
        }
        Wlist.append(word);
    }

    QString result = Wlist.join(" ");

    QMessageBox::information(this, "Результат", result);
}
void MainWindow::on_pushButton_1_clicked()
{
    static QRegularExpression regex("^#[0-9A-Fa-f]{6}$");
    QString S1= ui->lineEdit->text();
    if(regex.match(S1).hasMatch()){
        ui->resultlabel->setText("Строка соответствует формату!");
        ui->frame->setStyleSheet("background-color: " + S1 + "; border: 1px solid grey;");
    }
    else{
        QMessageBox:: critical(this, "Ошибка", "Некорректный формат! (Корректный пример: #111111) ");
        ui->frame->setStyleSheet("background-color: none; border: 1px solid red;");
    }
}


void MainWindow::on_pushButton_2_clicked()
{
    ui->resultlabel->clear();
    ui->lineEdit->setText("0");
    ui->frame->setStyleSheet("background-color: none;");
}



void MainWindow::on_pushButton_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
    ui->stackedWidget->show();
}


void MainWindow::on_pushButton_4_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
    ui->stackedWidget->show();
}


void MainWindow::on_pushButton_5_clicked()
{
    ui->stroka->clear();
}

