#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMouseEvent>
#include <QFileDialog>
#include <QColorDialog>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow), modified(false),
    currentfilename("")
{
    ui->setupUi(this);
    label = new QLabel("Цвет: ");
    ui->toolBar->addWidget(label);
    frame = new QFrame();
    frame->setFixedSize(30, 30);
    frame->setStyleSheet("QFrame { background-color: black; }");
    ui->toolBar->addWidget(frame);
    ui->toolBar->setStyleSheet("QToolBar { background-color: #696969; }");
    ui->menubar->setStyleSheet("QMenuBar { background-color: #696969; }");
    type = "Line";
    color = "black";
    isDrawing = false;
    shape = nullptr;
}

MainWindow::~MainWindow()
{
    qDeleteAll(shapes);
    delete ui;
}
void MainWindow::documentmodified()
{
    if (!modified) {
        modified = true;
        WindowTitle();
    }
}
void MainWindow::WindowTitle()
{
    QString title = "Графический редактор";
    if (!currentfilename.isEmpty()) {
        title = QFileInfo(currentfilename).fileName() + " - " + title;
    }
    if (modified) {
        title += " [*]";
    }
    setWindowTitle(title);
}
bool MainWindow::maybeSave()
{
    if (!modified) {
        return true;
    }

    const QMessageBox::StandardButton ret = QMessageBox::warning(
        this, tr("Документ изменен"),
        tr("Документ содержит несохраненные изменения.\n"
           "Хотите сохранить изменения?"),
        QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);

    switch (ret) {
    case QMessageBox::Save:
        return save1();
    case QMessageBox::Cancel:
        return false;
    default:
        return true;
    }
}
bool MainWindow::save1()
{
    QString filename;
    if (currentfilename.isEmpty()) {
        filename = QFileDialog::getSaveFileName(this, "Сохранить фигуры", "",
                                                "Текстовые файлы (*.txt);;Все файлы (*)");
        if (filename.isEmpty()) {
            return false;
        }
    } else {
        filename = currentfilename;
    }

    save(filename);
    return !modified;
}
void MainWindow::on_action_4_triggered()
{
    type = "Прямоугольник";
}
void MainWindow::on_action_5_triggered()
{
    type = "Эллипс";
}
void MainWindow::on_action_3_triggered()
{
    type = "Треугольник";
}

void MainWindow:: mousePressEvent(QMouseEvent *event){
    if (event->button() == Qt::LeftButton && !isDrawing) {
         isDrawing = true;
        startPos = event->pos();
        if (type== "Прямоугольник"){
            shape = new Rectangle(color, {startPos, startPos});
        }
        else if (type == "Эллипс"){
            shape  = new Ellipse(color, {startPos, startPos});
        }
        else if (type == "Треугольник"){
            shape  = new Triangle(color, {startPos, startPos});
        }
    }

}
void MainWindow::mouseMoveEvent(QMouseEvent *event) {
    if (shape) {
        QPointF endPos = event->pos();
        shape->updateCoords({startPos, endPos});
        update();
    }
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event) {
    if (event->button() == Qt::LeftButton && isDrawing && shape) {
        QPointF endPos = event->pos();
        shape->updateCoords({startPos, endPos});

        shapes.append(shape);
        shape = nullptr;
        isDrawing = false;
        documentmodified();
        update();
    }
}

void MainWindow::paintEvent(QPaintEvent *event) {
    Q_UNUSED(event);
    QPainter painter(this);

    for (Shape* shape : shapes) {
        shape->draw(&painter);
    }
    if (shape) {
        shape->draw(&painter);
    }
}

void MainWindow::on_action_7_triggered()
{
    color = "red";
    frame->setStyleSheet("QFrame { background-color: red; }");
}


void MainWindow::on_action_8_triggered()
{
    color = "green";
    frame->setStyleSheet("QFrame { background-color: green; }");
}



void MainWindow::on_action_9_triggered()
{
    color = "blue";
    frame->setStyleSheet("QFrame { background-color: blue; }");
}


void MainWindow::on_action_10_triggered()
{
    color = "yellow";
    frame->setStyleSheet("QFrame { background-color: yellow; }");
}


void MainWindow::on_action_11_triggered()
{
    color = "white";
    frame->setStyleSheet("QFrame { background-color: white; }");
}

QTextStream& operator<<(QTextStream &out, const MainWindow &window) {
    for (const Shape* shape : window.shapes) {
        if (shape) {
            out << shape->toString() << "\n";
        }
    }
    return out;
}

QTextStream& operator>>(QTextStream &in, Shape*& shape) {
    QString line = in.readLine();
    if(line.isEmpty()) return in;
    QStringList parts = line.split(' ');
    if (parts.size() < 6) return in;
    QString type = parts[0];
    QString color = parts[1];
    QVector<QPointF> coords;
    double x1 = parts[2].toDouble();
    double y1 = parts[3].toDouble();
    double x2 = parts[4].toDouble();
    double y2 = parts[5].toDouble();

    coords.append(QPointF(x1, y1));
    coords.append(QPointF(x2, y2));

    if(type == "Прямоугольник"){
        shape = new Rectangle(color, coords);
    }
    else if (type == "Эллипс") {
        shape = new Ellipse(color, coords);
    }
    else if (type == "Треугольник") {
        shape = new Triangle(color, coords);
    }
    return in;
}
void MainWindow::save(const QString &filename) {
    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Ошибка", "Не удалось открыть файл для записи!");
        return;
    }

    QTextStream out(&file);
    out << *this;
    file.close();
    currentfilename = filename;
    modified = false;
    WindowTitle();
    QMessageBox::information(this, "Успех", "Фигуры сохранены в файл!");
}
void MainWindow :: load(const QString &filename){
    if (!maybeSave()) {
        return;
    }
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Ошибка", "Не удалось открыть файл для чтения!");
        return;
    }
    qDeleteAll(shapes);
    shapes.clear();
    QTextStream in(&file);
    while(!in.atEnd()){
        Shape* newS = nullptr;
        in>> newS;
        if (newS) {
            shapes.append(newS);
        }
    }
    file.close();
    currentfilename = filename;
    modified = false;
    update();
    WindowTitle();

}
void MainWindow::on_action_triggered()
{
    save1();
}


void MainWindow::on_action_2_triggered()
{
    QString filename = QFileDialog::getOpenFileName(this, "Загрузить фигуры","", "Текстовые файлы (*.txt);;Все файлы (*)");
    if (!filename.isEmpty()){
        load(filename);
    }
}




void MainWindow::on_action_6_triggered()
{
    if (maybeSave()) {
        qDeleteAll(shapes);
        shapes.clear();
        currentfilename.clear();
        modified = false;
        WindowTitle();
        update();
    }
}
void MainWindow::closeEvent(QCloseEvent *event)
{
    if (maybeSave()) {
        event->accept();
    } else {
        event->ignore();
    }
}


void MainWindow::on_action_12_triggered()
{
    QColor selectedColor = QColorDialog::getColor(Qt::white, this, "Выберите цвет");
    if (selectedColor.isValid()) {
        color = selectedColor.name();
        frame->setStyleSheet(QString("QFrame { background-color: %1; }").arg(color));
    }
}

