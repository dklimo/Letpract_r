#ifndef SHAPE_H
#define SHAPE_H
#include <QGraphicsScene>
#include <QPainter>
class Shape {
protected:
    QString type;
    QString color;
    QVector<QPointF> coo;

public:
    Shape(const QString& type, const QString& color, const QVector<QPointF>& coords) : type(type), color(color), coo(coords) {}

    virtual ~Shape() {}
    virtual void draw(QPainter* painter) const = 0;
    QString getType() const { return type; }
    QString getColor() const { return color; }
    QVector<QPointF> getCoo() const { return coo; }
    virtual void updateCoords(const QVector<QPointF>& newCoords) {
        if (newCoords.size() >= 2) {
            coo = newCoords;
        }
    }
    virtual QString toString() const = 0;
};

class Rectangle : public Shape {
public:
    Rectangle(const QString& color, const QVector<QPointF>& coords)
        : Shape("Прямоугольник", color, coords) {}
    void draw(QPainter* painter) const override {
        if (coo.size() >= 2) {
            painter->setPen(QPen(QColor(color)));
            painter->setBrush(QBrush(QColor(color), Qt::SolidPattern));
            QRectF rect(coo[0], coo[1]);
            painter->drawRect(rect);
        }
    }
    void updateCoords(const QVector<QPointF>& newCoords) override {
        if (newCoords.size() == 2) {
            coo = newCoords;
        }
    }
    QString toString() const override {
        return QString("Прямоугольник %1 %2 %3 %4 %5")
        .arg(color)
            .arg(coo[0].x())
            .arg(coo[0].y())
            .arg(coo[1].x())
            .arg(coo[1].y());
    }
};


class Ellipse : public Shape {
public:
    Ellipse(const QString& color, const QVector<QPointF>& coords)
        : Shape("Эллипс", color, coords) {}

    void draw(QPainter* painter) const override {
        if (coo.size() >= 2) {
            painter->setPen(QPen(QColor(color)));
            painter->setBrush(QBrush(QColor(color), Qt::SolidPattern));
            QRectF rect(coo[0], coo[1]);
            painter->drawEllipse(rect);
        }
    }
    void updateCoords(const QVector<QPointF>& newCoords) override {
        if (newCoords.size() == 2) {
            coo = newCoords;
        }
    }
    QString toString() const override {
            return QString("Эллипс %1 %2 %3 %4 %5")
            .arg(color)
                .arg(coo[0].x())
                .arg(coo[0].y())
                .arg(coo[1].x())
                .arg(coo[1].y());
    }
};


class Triangle : public Shape {
public:
    Triangle(const QString& color, const QVector<QPointF>& coords)
        : Shape("Треугольник", color, coords) {}

    void draw(QPainter* painter) const override {
        if (coo.size() >= 2) {
             painter->setPen(QPen(QColor(color)));
            painter->setBrush(QBrush(QColor(color), Qt::SolidPattern));
            QRectF rect(coo[0], coo[1]);
            QPolygonF triangle;
            triangle << QPointF(rect.center().x(), rect.top())
                     << rect.bottomRight()
                     << rect.bottomLeft();

            painter->drawPolygon(triangle);
        }
    }
    QString toString() const override {
            return QString("Треугольник %1 %2 %3 %4 %5")
            .arg(color)
                .arg(coo[0].x())
                .arg(coo[0].y())
                .arg(coo[1].x())
                .arg(coo[1].y());
    }
};
#endif // SHAPE_H
