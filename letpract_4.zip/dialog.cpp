#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);
    setWindowTitle("Введите имя файла");
}

Dialog::~Dialog()
{
    delete ui;
}

QString Dialog:: getName() const {
    return ui->lineEdit->text();
}
