#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QFileInfo>
#include "dialog.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->groupBox->hide();
    ui->groupBox_2->hide();
    ui->groupBox_3->hide();

    connect(ui->action_5, &QAction::triggered, this, &MainWindow::restoreorig1);
    connect(ui->action_6, &QAction::triggered, this, &MainWindow::restoreorig2);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionOpenTxt_triggered()
{
    Dialog dialog(this);
    if (dialog.exec() == QDialog::Accepted) {
        QString fileName = dialog.getName();
        if (!fileName.isEmpty()) {
            openTxT(fileName);
        }
    }

}

void MainWindow::openTxT(const QString& filename) {
    if (!ui->textEdit->toPlainText().isEmpty() &&
        !ui->textEdit_2->toPlainText().isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Все текстовые поля заполнены. Закройте одно перед открытием нового файла.");
        return;
    }

    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly)) {
        QMessageBox::warning(this, "Ошибка", "Не удалось открыть файл: " + filename);
        return;
    }

    QTextStream in(&file);
    QString text;
    QString result;
    QVector<Student>* targetStudents;
    bool isFirst = ui->textEdit->toPlainText().isEmpty();

    if (isFirst) {
        file1 = filename;
        targetStudents = &students1;
        students1.clear();
    } else {
        file2 = filename;
        targetStudents = &students2;
        students2.clear();
    }

    while (!in.atEnd()) {
        QString line = in.readLine();
        text += line + '\n';

        QTextStream lin(&line);
        Student s;
        lin >> s;

        if (lin.status() == QTextStream::Ok) {
            targetStudents->push_back(s);
            QTextStream res(&result);
            res<<s<<'\n';
        }
    }
    file.close();

    if (isFirst) {
        ui->textEdit->setText(result);
        ui->groupBox->show();
        orig1 = result;
    } else {
        ui->textEdit_2->setText(result);
        ui->groupBox_2->show();
        orig2 = result;
    }
}


void MainWindow::on_action_triggered()
{
    Dialog dialog(this);
    if (dialog.exec() == QDialog::Accepted) {
        QString fileName = dialog.getName();
        if (!fileName.isEmpty()) {
            closeFile(fileName);
        }
    }

}

void MainWindow:: closeFile(const QString& filename){
    if (filename == file1) {
        ui->textEdit->clear();
        students1.clear();
        ui->groupBox->hide();
        file1.clear();
    }
    else if (filename == file2) {
        ui->textEdit_2->clear();
        students2.clear();
        ui->groupBox_2->hide();
        file2.clear();
    }
    else {
        QMessageBox::warning(this, "Ошибка", "Файл не найден среди открытых: " + filename);
    }
}
bool MainWindow::checkStud() {
    if (students1.isEmpty() || students2.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, сначала откройте оба файла со студентами");
        return false;
    }
    if(orig2 != ui->textEdit_2->toPlainText() || orig1 != ui->textEdit->toPlainText()){
        QMessageBox::warning(this, "Предупреждение", "Пожалуйста, сначала сохраните изменения");
        return false;
    }
    if (!ui->textEdit_3->toPlainText().isEmpty()) {
        int ret = QMessageBox::question(this, "Подтверждение", "Результаты предыдущей операции будут удалены. Продолжить?", QMessageBox::Yes | QMessageBox::No);

        if (ret == QMessageBox::No) {
            return false;
        }

        ui->textEdit_3->clear();
        students.clear();
    }

    return true;
}
void MainWindow:: madeStud3()
{
    QString result;
    QTextStream res(&result);

    if (students.isEmpty()) {
        res << "Результат пуст.\n";
    } else {
        for (const auto& student : students) {
            res << student << "\n";
        }
    }

    ui->textEdit_3->setText(result);
    ui->groupBox_3->show();
}
void MainWindow::on_action_3_triggered()
{
    //пересечение
    if (!checkStud()) return;
    for (int i = 0; i < students1.size(); ++i)
    {
        for (int j = 0; j < students2.size(); ++j)
        {
            if (students1[i] == students2[j]) students.push_back(students1[i]);
        }
    }
    madeStud3();
}


void MainWindow::on_action_2_triggered()
{
    //обьединение
    if (!checkStud()) return;
    bool isHere;
    for (int i = 0; i < students1.size(); ++i)
    {
        students.push_back(students1[i]);
    }
    for (int i = 0; i < students2.size(); ++i)
    {
        isHere = false;
        for (int j = 0; j < students1.size(); ++j)
        {
            if (students2[i] == students1[j]) isHere = true;
        }
        if  (!isHere) students.push_back(students2[i]);
    }
    madeStud3();
}


void MainWindow::on_action_4_triggered()
{
    //разность
    if (!checkStud()) return;
    bool isHere;
    for (int i = 0; i < students1.size(); ++i)
    {
        isHere = false;
        for (int j = 0; j < students2.size(); ++j)
        {
            if (students1[i] == students2[j]) isHere = true;
        }
        if  (!isHere) students.push_back(students1[i]);
    }
    madeStud3();
}


void MainWindow::on_actionSaveTxt_triggered()
{
    Dialog dialog(this);
    if (dialog.exec() == QDialog::Accepted) {
        QString fileName = dialog.getName();
        if (!fileName.isEmpty()) {
            saveTxT(fileName);
        }
    }
}

void MainWindow:: saveTxT(const QString& filename){
    QString content;
    if (filename == file1) {
        content = ui->textEdit->toPlainText();
    }
    else if (filename == file2) {
        content = ui->textEdit_2->toPlainText();
    }
    else if (filename == fileres){
        content = ui->textEdit_3->toPlainText();
    }
    else {
        QMessageBox::warning(this, "Ошибка", "Файл не связан с открытыми документами");
        return;
    }
    if (content.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Нет данных для сохранения");
        return;
    }
    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Ошибка", "Не удалось открыть файл для записи: " + filename);
        return;
    }
    QTextStream out(&file);
    out << content;
    file.close();
    QMessageBox::information(this, "Успех", "Файл " + filename + " успешно сохранён");
    if(filename == file1 || filename == file2){
    closeFile(filename);
    openTxT(filename);
    }
}

void MainWindow::restoreorig1()
{
    if (file1.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Первый файл не открыт или был закрыт.");
        return;
    }

    if (ui->textEdit->toPlainText() == orig1) {
        QMessageBox::information(this, "Информация", "Текст в первом документе не изменялся.");
        return;
    }

    ui->textEdit->setPlainText(orig1);
    QMessageBox::information(this, "Успех", "Первый документ восстановлен");
}
void MainWindow::restoreorig2()
{

    if (file2.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Второй файл не открыт или был закрыт.");
        return;
    }

    if (ui->textEdit_2->toPlainText() == orig2) {
        QMessageBox::information(this, "Информация", "Текст во втором документе не изменялся.");
        return;
    }

    ui->textEdit_2->setPlainText(orig2);
    QMessageBox::information(this, "Успех", "Второй документ восстановлен");
}

void MainWindow::on_action_7_triggered()
{
    QString info;
    if(!file1.isEmpty()){
        info+= "Первый документ - "+ file1 + '\n';
    }
    if(!file2.isEmpty()){
        info+= "Второй документ - " + file2 + '\n';
    }
    if(info.isEmpty()) {
        info = "Нет открытых файлов";
    }
    QMessageBox::information(this, "Инфо", "Открытые файлы:\n" + info);
}


void MainWindow::on_actionSaveBin_triggered()
{
    Dialog dialog(this);
    if (dialog.exec() == QDialog::Accepted) {
        QString fileName = dialog.getName();
        if (!fileName.isEmpty()) {
            saveBin(fileName);
        }
    }
}

void MainWindow::saveBin(const QString& filename) {
    QString content;
    if (filename == file1) {
        content = ui->textEdit->toPlainText();
    }
    else if (filename == file2) {
        content = ui->textEdit_2->toPlainText();
    }
    else if (filename == fileres) {
        content = ui->textEdit_3->toPlainText();
    }
    else {
        QMessageBox::warning(this, "Ошибка", "Файл не связан с открытыми документами");
        return;
    }

    if (content.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Нет данных для сохранения");
        return;
    }

    QFileInfo fileInfo(filename);
    QString binfile = fileInfo.path() + "/" + fileInfo.completeBaseName() + ".bin";

    QFile file(binfile);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        QMessageBox::warning(this, "Ошибка", "Не удалось открыть файл для записи: " + file.errorString());
        return;
    }

    QDataStream out(&file);
    out << content;

    QMessageBox::information(this, "Успех", "Файл " + fileInfo.fileName() + " успешно сохранён");
}

void MainWindow::on_pushButton_clicked()
{
    ui->groupBox_3->hide();
}

