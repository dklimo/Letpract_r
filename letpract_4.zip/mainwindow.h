#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include <QTextStream>
#include <QDataStream>
#include <QFile>
QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    void on_actionOpenTxt_triggered();
    void on_action_triggered();

    void on_action_3_triggered();

    void on_action_2_triggered();

    void on_action_4_triggered();

    void on_actionSaveTxt_triggered();
    void restoreorig1();
    void restoreorig2();

    void on_action_7_triggered();

    void on_actionSaveBin_triggered();

    void on_pushButton_clicked();

private:
    struct Student
    {
        long long num;
        QString name;
        int group;
        double grade;
        bool operator==(const Student& other)
        {
            return num == other.num && name == other.name && group == other.group && grade == other.grade;
        }

        bool operator!=(const Student& other)
        {
            return !(*this == other);
        }
    };
    Ui::MainWindow *ui;
    QVector<Student> students1;
    QVector<Student> students2;
    QVector<Student> students;

    QString file1;
    QString file2;
    QString fileres = "result.txt";

    QString orig1;
    QString orig2;

    void openTxT(const QString& filename);
    void closeFile(const QString& filename);
    void saveTxT(const QString& filename);
    void saveBin(const QString& filename);
    void madeStud3();
    bool checkStud();

    friend QTextStream &operator>>(QTextStream &in, Student &s){
        in>>s.num>>s.name>>s.group>>s.grade;
        return in;
    }
    friend QTextStream &operator<<(QTextStream &out, const Student &s){
        out << s.num << " " << s.name << " " << s.group << " " << s.grade;
        return out;
    }
};
#endif // MAINWINDOW_H
