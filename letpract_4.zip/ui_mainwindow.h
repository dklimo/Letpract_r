/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *action_2;
    QAction *action_3;
    QAction *action_4;
    QAction *actionOpenTxt;
    QAction *actionSaveTxt;
    QAction *actionSaveBin;
    QAction *action;
    QAction *action_5;
    QAction *action_6;
    QAction *action_7;
    QWidget *centralwidget;
    QGroupBox *groupBox;
    QTextEdit *textEdit;
    QGroupBox *groupBox_2;
    QTextEdit *textEdit_2;
    QGroupBox *groupBox_3;
    QTextEdit *textEdit_3;
    QPushButton *pushButton;
    QLabel *label;
    QMenuBar *menubar;
    QMenu *menu;
    QMenu *menu_3;
    QMenu *menu_4;
    QMenu *menu_2;
    QMenu *menu_5;
    QMenu *menu_6;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->setEnabled(true);
        MainWindow->resize(718, 514);
        MainWindow->setMouseTracking(true);
        action_2 = new QAction(MainWindow);
        action_2->setObjectName("action_2");
        QIcon icon(QIcon::fromTheme(QIcon::ThemeIcon::ListAdd));
        action_2->setIcon(icon);
        action_3 = new QAction(MainWindow);
        action_3->setObjectName("action_3");
        QIcon icon1(QIcon::fromTheme(QIcon::ThemeIcon::MediaPlaylistShuffle));
        action_3->setIcon(icon1);
        action_4 = new QAction(MainWindow);
        action_4->setObjectName("action_4");
        QIcon icon2(QIcon::fromTheme(QIcon::ThemeIcon::ListRemove));
        action_4->setIcon(icon2);
        actionOpenTxt = new QAction(MainWindow);
        actionOpenTxt->setObjectName("actionOpenTxt");
        actionSaveTxt = new QAction(MainWindow);
        actionSaveTxt->setObjectName("actionSaveTxt");
        actionSaveBin = new QAction(MainWindow);
        actionSaveBin->setObjectName("actionSaveBin");
        action = new QAction(MainWindow);
        action->setObjectName("action");
        QIcon icon3(QIcon::fromTheme(QIcon::ThemeIcon::EditClear));
        action->setIcon(icon3);
        action_5 = new QAction(MainWindow);
        action_5->setObjectName("action_5");
        QIcon icon4(QIcon::fromTheme(QIcon::ThemeIcon::EditUndo));
        action_5->setIcon(icon4);
        action_6 = new QAction(MainWindow);
        action_6->setObjectName("action_6");
        action_6->setIcon(icon4);
        action_7 = new QAction(MainWindow);
        action_7->setObjectName("action_7");
        QIcon icon5(QIcon::fromTheme(QIcon::ThemeIcon::HelpAbout));
        action_7->setIcon(icon5);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName("groupBox");
        groupBox->setGeometry(QRect(10, 20, 301, 211));
        textEdit = new QTextEdit(groupBox);
        textEdit->setObjectName("textEdit");
        textEdit->setGeometry(QRect(10, 30, 281, 171));
        groupBox_2 = new QGroupBox(centralwidget);
        groupBox_2->setObjectName("groupBox_2");
        groupBox_2->setGeometry(QRect(10, 240, 301, 211));
        textEdit_2 = new QTextEdit(groupBox_2);
        textEdit_2->setObjectName("textEdit_2");
        textEdit_2->setGeometry(QRect(10, 30, 281, 171));
        groupBox_3 = new QGroupBox(centralwidget);
        groupBox_3->setObjectName("groupBox_3");
        groupBox_3->setGeometry(QRect(330, 10, 341, 221));
        textEdit_3 = new QTextEdit(groupBox_3);
        textEdit_3->setObjectName("textEdit_3");
        textEdit_3->setGeometry(QRect(10, 40, 281, 171));
        pushButton = new QPushButton(groupBox_3);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(300, 30, 31, 29));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(510, 440, 191, 20));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 718, 25));
        menu = new QMenu(menubar);
        menu->setObjectName("menu");
        menu_3 = new QMenu(menu);
        menu_3->setObjectName("menu_3");
        QIcon icon6(QIcon::fromTheme(QIcon::ThemeIcon::DocumentOpen));
        menu_3->setIcon(icon6);
        menu_4 = new QMenu(menu);
        menu_4->setObjectName("menu_4");
        QIcon icon7(QIcon::fromTheme(QIcon::ThemeIcon::DocumentSave));
        menu_4->setIcon(icon7);
        menu_2 = new QMenu(menubar);
        menu_2->setObjectName("menu_2");
        menu_5 = new QMenu(menubar);
        menu_5->setObjectName("menu_5");
        menu_6 = new QMenu(menubar);
        menu_6->setObjectName("menu_6");
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menu->menuAction());
        menubar->addAction(menu_2->menuAction());
        menubar->addAction(menu_5->menuAction());
        menubar->addAction(menu_6->menuAction());
        menu->addSeparator();
        menu->addAction(menu_3->menuAction());
        menu->addAction(menu_4->menuAction());
        menu->addAction(action);
        menu_3->addAction(actionOpenTxt);
        menu_4->addAction(actionSaveTxt);
        menu_4->addAction(actionSaveBin);
        menu_2->addAction(action_2);
        menu_2->addAction(action_3);
        menu_2->addAction(action_4);
        menu_5->addAction(action_5);
        menu_5->addAction(action_6);
        menu_6->addAction(action_7);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        action_2->setText(QCoreApplication::translate("MainWindow", "\320\236\320\261\321\214\320\265\320\264\320\270\320\275\320\265\320\275\320\270\320\265", nullptr));
        action_3->setText(QCoreApplication::translate("MainWindow", "\320\237\320\265\321\200\320\265\321\201\320\265\321\207\320\265\320\275\320\270\320\265", nullptr));
        action_4->setText(QCoreApplication::translate("MainWindow", "\320\240\320\260\320\267\320\275\320\276\321\201\321\202\321\214", nullptr));
        actionOpenTxt->setText(QCoreApplication::translate("MainWindow", "\320\242\320\265\320\272\321\201\321\202\320\276\320\262\321\213\320\271 \321\204\320\276\321\200\320\274\320\260\321\202", nullptr));
        actionSaveTxt->setText(QCoreApplication::translate("MainWindow", "\320\242\320\265\320\272\321\201\321\202\320\276\320\262\321\213\320\271 \321\204\320\276\321\200\320\274\320\260\321\202", nullptr));
#if QT_CONFIG(tooltip)
        actionSaveTxt->setToolTip(QCoreApplication::translate("MainWindow", "\320\224\320\273\321\217 \321\201\320\276\321\205\321\200\320\260\320\275\320\265\320\275\320\270\321\217 \321\200\320\265\320\267\321\203\320\273\321\214\321\202\320\260\321\202\320\260 \320\262\320\262\320\265\320\264\320\270\321\202\320\265 result.txt", nullptr));
#endif // QT_CONFIG(tooltip)
        actionSaveBin->setText(QCoreApplication::translate("MainWindow", "\320\221\320\270\320\275\320\260\321\200\320\275\321\213\320\271 \321\204\320\276\321\200\320\274\320\260\321\202", nullptr));
        action->setText(QCoreApplication::translate("MainWindow", "\320\227\320\260\320\272\321\200\321\213\321\202\321\214", nullptr));
        action_5->setText(QCoreApplication::translate("MainWindow", "\320\237\320\265\321\200\320\262\321\213\320\271 \320\264\320\276\320\272\321\203\320\274\320\265\320\275\321\202", nullptr));
        action_6->setText(QCoreApplication::translate("MainWindow", "\320\222\321\202\320\276\321\200\320\276\320\271 \320\264\320\276\320\272\321\203\320\274\320\265\320\275\321\202", nullptr));
        action_7->setText(QCoreApplication::translate("MainWindow", "\320\236\320\261 \320\276\321\202\320\272\321\200\321\213\321\202\321\213\321\205 \320\264\320\276\320\272\321\203\320\274\320\265\320\275\321\202\320\260\321\205", nullptr));
        groupBox->setTitle(QCoreApplication::translate("MainWindow", "\320\237\320\265\321\200\320\262\321\213\320\271 \320\264\320\276\320\272\321\203\320\274\320\265\320\275\321\202", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("MainWindow", "\320\222\321\202\320\276\321\200\320\276\320\271 \320\264\320\276\320\272\321\203\320\274\320\265\320\275\321\202", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("MainWindow", "\320\240\320\265\320\267\321\203\320\273\321\214\321\202\320\260\321\202", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "X", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "\320\232\320\273\320\270\320\274\320\276\320\262\320\270\321\207 \320\224\320\260\321\200\321\214\321\217, 5 \320\263\321\200\321\203\320\277\320\277\320\260", nullptr));
        menu->setTitle(QCoreApplication::translate("MainWindow", "\320\244\320\260\320\271\320\273", nullptr));
        menu_3->setTitle(QCoreApplication::translate("MainWindow", "\320\236\321\202\320\272\321\200\321\213\321\202\321\214", nullptr));
#if QT_CONFIG(tooltip)
        menu_4->setToolTip(QCoreApplication::translate("MainWindow", "\320\224\320\273\321\217 \321\201\320\276\321\205\321\200\320\260\320\275\320\265\320\275\320\270\321\217 \321\200\320\265\320\267\321\203\320\273\321\214\321\202\320\260\321\202\320\260 \320\262\320\262\320\276\320\264\320\270\321\202\320\265 result.txt", nullptr));
#endif // QT_CONFIG(tooltip)
        menu_4->setTitle(QCoreApplication::translate("MainWindow", "\320\241\320\276\321\205\321\200\320\260\320\275\320\270\321\202\321\214", nullptr));
        menu_2->setTitle(QCoreApplication::translate("MainWindow", "\320\237\321\200\320\260\320\262\320\272\320\260", nullptr));
        menu_5->setTitle(QCoreApplication::translate("MainWindow", "\320\222\320\276\321\201\321\201\321\202\320\260\320\275\320\276\320\262\320\270\321\202\321\214", nullptr));
        menu_6->setTitle(QCoreApplication::translate("MainWindow", "\320\230\320\275\321\204\320\276\321\200\320\274\320\260\321\206\320\270\321\217", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
