#include <QtTest>
#include <QDebug>
#include "../letpract_1/number.cpp"

//Климовия Дарья, 5 группа.
class NumberTest : public QObject
{
    Q_OBJECT

private slots:
    void initTestCase();
    void cleanupTestCase();

    void testDefaultConstructor();
    void testParametrizedConstructor();

    void testMaxCh_data();
    void testMaxCh();
    void testGcd_data();
    void testGcd();
    void testStep_data();
    void testStep();
    void testPoiskchWithNoSol();
    void testPoiskchWithSol();
    void testProstoe();
};

void NumberTest::initTestCase()
{
    qDebug("Initializing test cases...");
}

void NumberTest::cleanupTestCase()
{
    qDebug("Cleaning up after test cases...");
}

void NumberTest::testDefaultConstructor()
{
    Number num;
    QCOMPARE(num.getNum(), 0);
}

void NumberTest::testParametrizedConstructor()
{
    Number num(42);
    QCOMPARE(num.getNum(), 42);
}

void NumberTest::testMaxCh_data()
{
    QTest::addColumn<int>("input");
    QTest::addColumn<QString>("expected");

    QTest::newRow("zero") << 0
                          << "Исходное число: 0\nМаксимальная цифра: 0\nРезультат обработки: 0";
    QTest::newRow("single digit") << 5
                                  << "Исходное число: 5\nМаксимальная цифра: 5\nРезультат обработки: 55";
    QTest::newRow("multiple digits") << 12345
                                     << "Исходное число: 12345\nМаксимальная цифра: 5\nРезультат обработки: 123455";
    QTest::newRow("all same digits") << 999
                                     << "Исходное число: 999\nМаксимальная цифра: 9\nРезультат обработки: 999999";
}

void NumberTest::testMaxCh()
{
    QFETCH(int, input);
    QFETCH(QString, expected);

    Number num(input);
    QString result = num.MaxCh();
    QCOMPARE(result, expected);
}



void NumberTest::testGcd_data()
{
    QTest::addColumn<int>("num1");
    QTest::addColumn<int>("num2");
    QTest::addColumn<QString>("expected");

    QTest::newRow("both zero") << 0 << 0 << "НОД не существует (оба числа равны 0)";
    QTest::newRow("first zero") << 0 << 15 << "НОД чисел 0 и 15 равен: 15";
    QTest::newRow("second zero") << 21 << 0 << "НОД чисел 21 и 0 равен: 21";
    QTest::newRow("coprime") << 8 << 15 << "НОД чисел 8 и 15 равен: 1";
    QTest::newRow("non-coprime") << 36 << 48 << "НОД чисел 36 и 48 равен: 12";
    QTest::newRow("equal numbers") << 17 << 17 << "НОД чисел 17 и 17 равен: 17";
}

void NumberTest::testGcd()
{
    QFETCH(int, num1);
    QFETCH(int, num2);
    QFETCH(QString, expected);

    Number n1(num1);
    Number n2(num2);
    QString result = n1.gcd(n2);
    QCOMPARE(result, expected);
}

void NumberTest::testPoiskchWithNoSol()
{
    Number num;
    QString result = num.poiskch(4, 2);
    QVERIFY(result.contains("Не удалось найти"));
}

void NumberTest::testPoiskchWithSol()
{
    Number num;
    QString result = num.poiskch(4, 1);
    QVERIFY(result.contains("Найдены простые числа"));
}

void NumberTest::testStep_data()
{
    QTest::addColumn<int>("input");
    QTest::addColumn<QString>("expected");

    QTest::newRow("power of two") << 16 << "Число 16 между 8 (2^3) и 16 (2^4).";
    QTest::newRow("between powers") << 10 << "Число 10 между 8 (2^3) и 16 (2^4).";
    QTest::newRow("zero") << 0 << "Число 0 не является положительным.";
    QTest::newRow("one") << 1 << "Число 1 между 1 (2^0) и 2 (2^1).";
}

void NumberTest::testStep()
{
    QFETCH(int, input);
    QFETCH(QString, expected);

    Number num(input);
    QString result = num.step();
    QCOMPARE(result, expected);
}

void NumberTest::testProstoe()
{
    Number num;
    QVERIFY(num.prostoe(2));
    QVERIFY(num.prostoe(3));
    QVERIFY(num.prostoe(17));
    QVERIFY(!num.prostoe(1));
    QVERIFY(!num.prostoe(4));
    QVERIFY(!num.prostoe(15));
    QVERIFY(!num.prostoe(0));
    QVERIFY(!num.prostoe(-5));
}


QTEST_APPLESS_MAIN(NumberTest)
#include "numbertest.moc"
