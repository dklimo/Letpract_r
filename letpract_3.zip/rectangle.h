#ifndef RECTANGLE_H
#define RECTANGLE_H
#include "figure.h"

class Rectangle : public Figure {
private:
     double x,y;
public:
     Rectangle(double length, double width, double x=0, double y=0) : Figure(length, width), x(x), y(y) {}

    double square() const override {
        return first * next;
    }

    double perimeter() const override {
        return 2 * (first + next);
    }

    void move(double dx, double dy) override {
        x += dx;
        y += dy;
    }
    double getX() const { return x; }
    double getY() const { return y; }
};
#endif // RECTANGLE_H
