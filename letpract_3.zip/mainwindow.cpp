#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "triangle.h"
#include "rectangle.h"
#include <QMessageBox>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->groupBox->hide();
    ui->table->setColumnCount(7);
    ui->table->setHorizontalHeaderLabels({"Имя", "Длина","Ширина","Площадь","Периметр","X","Y"});
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QString N = ui->name->text();
    double L = ui->len->text().toDouble();
    double W = ui->weig->text().toDouble();
    if (N.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Введите название фигуры");
        ui->name->setFocus();
        return;
    }
    if (L==0) {
        QMessageBox::warning(this, "Ошибка", "Введите длину");
        ui->len->setFocus();
        return;
    }
    if (W==0) {
        QMessageBox::warning(this, "Ошибка", "Введите ширину");
        ui->weig->setFocus();
        return;
    }
    if (L <= 0 || W <= 0) {
        QMessageBox::warning(this, "Ошибка", "Длина и ширина должны быть положительными числами");
        return;
    }
    bool nameEx = false;
    for (int i = 0; i < ui->table->rowCount(); ++i) {
        if (ui->table->item(i, 0) && ui->table->item(i, 0)->text() == N) {
            nameEx = true;
            break;
        }
    }
    if (nameEx) {
        QMessageBox::warning(this, "Ошибка", "Фигура с таким именем уже существует!");
        return;
    }
    int row = ui->table->rowCount();
    ui->table->insertRow(row);
    ui->table->setItem(row, 0, new QTableWidgetItem(N));
    ui->table->setItem(row, 1, new QTableWidgetItem(QString::number(L)));
    ui->table->setItem(row, 2, new QTableWidgetItem(QString::number(W)));
    if (N.contains("Треугольник", Qt::CaseInsensitive)){
        Triangle T1(L,W);
        ui->table->setItem(row, 3, new QTableWidgetItem(QString::number(T1.square())));
        ui->table->setItem(row, 4, new QTableWidgetItem(QString::number(T1.perimeter())));
        ui->table->setItem(row, 5, new QTableWidgetItem(QString::number(T1.getX())));
        ui->table->setItem(row, 6, new QTableWidgetItem(QString::number(T1.getY())));
    }
    else if(N.contains("Прямоугольник", Qt::CaseInsensitive)){
        Rectangle R1(L,W);
        ui->table->setItem(row, 3, new QTableWidgetItem(QString::number(R1.square())));
        ui->table->setItem(row, 4, new QTableWidgetItem(QString::number(R1.perimeter())));
        ui->table->setItem(row, 5, new QTableWidgetItem(QString::number(R1.getX())));
        ui->table->setItem(row, 6, new QTableWidgetItem(QString::number(R1.getY())));
    }
    else {
        QMessageBox::information(this, "Информация", "Данное имя фигуры не поддерживается. Поддерживаются: Все слова (словосочетания) включающие Треугольник, Прямоугольник");
        ui->table->removeRow(row);
        return;
    }
}


void MainWindow::on_pushButton_2_clicked()
{
    double dx = ui->newX->text().toDouble();
    double dy = ui->newY->text().toDouble();
    QString N1 = ui->name->text();
    bool found = false;

    for(int row = 0; row < ui->table->rowCount(); row++){
        QTableWidgetItem* name = ui->table->item(row, 0);
        if(name && name->text() == N1){
            found = true;
            double L = ui->table->item(row, 1)->text().toDouble();
            double W = ui->table->item(row, 2)->text().toDouble();
            double x = ui->table->item(row, 5)->text().toDouble();
            double y = ui->table->item(row, 6)->text().toDouble();

            if (name->text().contains("Треугольник", Qt::CaseInsensitive)) {
                Triangle T2(L, W, x, y);
                T2.move(dx, dy);
                ui->table->setItem(row, 5, new QTableWidgetItem(QString::number(T2.getX())));
                ui->table->setItem(row, 6, new QTableWidgetItem(QString::number(T2.getY())));
            }
            else if (name->text().contains("Прямоугольник", Qt::CaseInsensitive)) {
                Rectangle R2(L, W, x, y);
                R2.move(dx, dy);
                ui->table->setItem(row, 5, new QTableWidgetItem(QString::number(R2.getX())));
                ui->table->setItem(row, 6, new QTableWidgetItem(QString::number(R2.getY())));
            }
            break;
        }
    }

    if (!found) {
        QMessageBox::warning(this, "Ошибка", QString("Фигура с именем '%1' не найдена").arg(N1));
    } else {
        QMessageBox::information(this, "Успех", "Координаты фигуры успешно обновлены");
    }
    ui->groupBox->hide();
    ui->newX->clear();
    ui->newY->clear();
}


void MainWindow::on_pushButton_3_clicked()
{
    ui->groupBox->show();
}


void MainWindow::on_pushButton_4_clicked()
{
    ui->table->setRowCount(0);
}

