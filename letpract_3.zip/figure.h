#ifndef FIGURE_H
#define FIGURE_H
#include <QString>
class Figure {
protected:
    double first;
    double next;
public:
    Figure(double f=0, double n=0) : first(f), next(n) {
    }
    virtual ~Figure() = default;
    virtual double square() const = 0;
    virtual double perimeter() const = 0;
    virtual void move(double a, double b) {
        first += a;
        next += b;
    }
};

#endif // FIGURE_H
