#include "rectangle.h"

Rectangle::Rectangle() {}
