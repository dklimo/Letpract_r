#ifndef TRIANGLE_H
#define TRIANGLE_H
#include "figure.h"
class Triangle : public Figure {
private:
    double x,y;
public:
    Triangle(double base, double height, double x=0, double y=0) : Figure(base, height), x(x), y(y) {}

    double square() const override {
        return 0.5 * first * next;
    }

    double perimeter() const override {
        return first + next + sqrt(first * first + next * next);
    }

    void move(double dx, double dy) override {
        x += dx;
        y += dy;
    }
    double getX() const  { return x; }
    double getY() const { return y; }
};

#endif // TRIANGLE_H
