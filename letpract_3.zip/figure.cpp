#include "figure.h"

Figure::Figure() {}
