#include "triangle.h"

Triangle::Triangle() {}
